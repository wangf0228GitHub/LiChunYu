#include "Variables.h"
_gFlags gFlags;
_RomStateFlags RomStateFlags;
uint8_t RomDatas[16];
uint8_t StepTimesAddr[3];//ʹ�ô�����Ӧ�ĵ�ַ
uint8_t CalcTimes[3];
uint8_t CalcTimes_D2;
uint8_t CalcTimes_BF;
uint8_t CalcTimesAddr;
uint8_t curHash[8];
uint8_t Com24DataBak[4];

