#ifndef   __OnCarProc_h__
#define   __OnCarProc_h__

#include <stdint.h>
#include "main.h"

void OnCarProc(void);
void Get2425TxParam(void);
void IRTx2425Frame(void);
void ProcCommand_26(void);
void ProcCommand_39(void);//Կ��ѧϰ����
#endif
