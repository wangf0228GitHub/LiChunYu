#ifndef __ButtonProc_h__
#define __ButtonProc_h__

#include "stdint.h"

void ButtionProc(void);
void RFIRTxProc(void);
void RFTxProc(void);
#endif


